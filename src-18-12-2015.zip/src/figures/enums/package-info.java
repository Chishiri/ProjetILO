/**
 * Ce package contient les différents énumérations utilisée pour choisir un type
 * de figure ou un type de ligne, ou encore sur quoi (trait ou remplissage)
 * appliquer une couleur.
 */
package figures.enums;