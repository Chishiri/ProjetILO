/**
 * Package contenant les différents Mouse[Motion]Listeners utilisés pour créer
 * à la souris chaque type de figure.
 * @author davidroussel
 */
package figures.creationListeners;
