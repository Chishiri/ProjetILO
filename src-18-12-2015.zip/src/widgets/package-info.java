/**
 * Package contenant les différents widgets (éléments graphiques)
 */
package widgets;
